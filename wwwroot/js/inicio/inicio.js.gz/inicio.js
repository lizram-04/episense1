$("#btn_ingresar").on('click', function(){
    $.redirect('/Home/Ingresar');
});

$("#btn_registrarse").on('click', function(){
    $.redirect('/Home/Registrar');
});